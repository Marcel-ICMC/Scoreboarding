/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package scoreboarding;

import scoreboarding.interfac.interfaci;

/**
 *
 * @author ICMC
 */
public class Scoreboarding {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        interfaci interfac = new interfaci();
        interfac.runInterface();
        // TODO code application logic here
    }
    
}
